font = ('times', 16, 'bold')
title = Label(main, text='Plant Disease Detection using Machine Learning')
title.config(bg='greenyellow', fg='dodger blue')
title.config(font=font)
title.config(height=3, width=120)
title.place(x=0, y=5)

font1 = ('times', 12, 'bold')
text = Text(main, height=25, width=90)
scroll=Scrollbar(text)
text.configure(yscrollcommand=scroll.set)
text.place(x=500, y=150)
text.config(font=font1)

font1 = ('times', 13, 'bold')
uploadButton = Button(main, text='Upload Kaggle Dataset', command=uploadDataset)
uploadButton.place(x=50, y=150)
uploadButton.config(font=font1)

featuresButton = Button(main, text='Data Preprocessing', command=featuresExtraction)
featuresButton.place(x=50, y=250)
featuresButton.config(font=font1)

cnnButton = Button(main, text='Run SVM Algorithm', command=runSVM)
cnnButton.place(x=50, y=350)
cnnButton.config(font=font1)

featuresButton = Button(main, text="Data Preprocessing", command=featuresExtraction)
featuresButton.place(x=50, y=250)
featuresButton.config(font=font1)

cnnButton = Button(main, text="Run SVM Algorithm", command=runSVM)
cnnButton.place(x=50, y=350)
cnnButton.config(font=font1)

cnnButton = Button(main, text="Run KNN Algorithm", command=runKNN)
cnnButton.place(x=50, y=450)
cnnButton.config(font=font1)

graphButton = Button(main, text="Performance Graph", command=plotComparison)
graphButton.place(x=50, y=550)
graphButton.config(font=font1)

predictButton = Button(main, text="plant Detection from Test Image", command=predict)
predictButton.place(x=50, y=650)
predictButton.config(font=font1)

main.config(bg='LightSkyBlue')
main.mainloop()
